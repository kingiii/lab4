// after parsing

class Factorial{
	public static void main(String[] a){
        System.out.println (new Fac().ComputeFac(10));
	}
}



class A{
    int ma;
    int ia;
    int a;
    public int funA2 () {
        
        return (0);
    }
    public int funA1 (int aaa) {
        
        return (0);
    }
}



class B extends A { 
    int nb;
    int jb;
    int b;
    public int funB () {
        
        return (0);
    }
}



class C extends B { 
    int pc;
    int kc;
    int c;
    public int funC () {
        
        return (0);
    }
}



class D{
    int md;
    int id;
    int d;
    public int funD2 () {
        
        return (0);
    }
    public int funD1 () {
        
        return (0);
    }
}




